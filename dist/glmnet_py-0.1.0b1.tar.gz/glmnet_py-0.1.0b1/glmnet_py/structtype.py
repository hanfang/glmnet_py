# -*- coding: utf-8 -*-
"""
This is a dummy class that allows the declaration of a struct similar to matlab

@author: bbalasub
"""
class structtype():
	pass

